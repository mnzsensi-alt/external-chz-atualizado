import Foundation

struct PatchStoreAlert: Identifiable {
    let id = UUID()
    let titleKey: String
    let messageKey: String
    var messageArgument: String?

    init(titleKey: String, messageKey: String, messageArgument: String? = nil) {
        self.titleKey = titleKey
        self.messageKey = messageKey
        self.messageArgument = messageArgument
    }

    func message(language: AppLanguage) -> String {
        if let messageArgument {
            return language.text(messageKey, messageArgument)
        }
        return language.text(messageKey)
    }
}

struct BundledPatchOption: Identifiable, Equatable {
    let number: Int
    let filename: String
    let packageName: String

    var id: String { filename }
    var tabIndex: Int { number <= 4 ? 0 : 1 }
    var avatarCacheTabIndex: Int { filename == "420 i.3105" ? 1 : tabIndex }
}

enum BundledPatchCatalog {
    static let options: [BundledPatchOption] = [
        BundledPatchOption(number: 1, filename: "420 i.3105", packageName: "420 i"),
        BundledPatchOption(number: 2, filename: "FF - Hs Alto 100-.3105", packageName: "Hs Alto 100%"),
        BundledPatchOption(number: 3, filename: "FF - Hs Alto Baypss.3105", packageName: "Hs Alto Baypss"),
        BundledPatchOption(number: 4, filename: "FF - Hs Pescoço 100-.3105", packageName: "Hs Pescoço 100%"),
        BundledPatchOption(number: 5, filename: "FF - Hs Pescoço-Alto.3105", packageName: "Hs Pescoço+Alto"),
        BundledPatchOption(number: 6, filename: "HS 100-.3105", packageName: "aim body jinex"),
        BundledPatchOption(number: 7, filename: "HS PESCOÇO - ANTENA-2.3105", packageName: "HS PESCOÇO + ANTENA"),
        BundledPatchOption(number: 8, filename: "HS PESCOÇO.3105", packageName: "HS BYPASS AP"),
        BundledPatchOption(number: 9, filename: "drive-01.3105", packageName: "Hs Alto+Pescoço MAX"),
        BundledPatchOption(number: 10, filename: "drive-02.3105", packageName: "Hs 100% Baypss"),
        BundledPatchOption(number: 11, filename: "drive-03.3105", packageName: "Hs Alto MAX"),
        BundledPatchOption(number: 12, filename: "drive-04.3105", packageName: "Hs Peito+Pescoço"),
        BundledPatchOption(number: 13, filename: "drive-05.3105", packageName: "Hs Alto"),
        BundledPatchOption(number: 14, filename: "drive-06.3105", packageName: "Hs Legit"),
        BundledPatchOption(number: 15, filename: "drive-07.3105", packageName: "Hs Pescoço+Antena"),
        BundledPatchOption(number: 16, filename: "drive-08.3105", packageName: "Hs Pescoço 100%"),
        BundledPatchOption(number: 17, filename: "drive-09.3105", packageName: "Hs Alto Antena MAX"),
        BundledPatchOption(number: 18, filename: "drive-10.3105", packageName: "Hs Pescoço MAX"),
        BundledPatchOption(number: 19, filename: "drive-11.3105", packageName: "Hs Alto+Pescoço"),
        BundledPatchOption(number: 20, filename: "drive-12.3105", packageName: "Hs Peito"),
        BundledPatchOption(number: 21, filename: "drive-13.3105", packageName: "Hs Pescoço Baypss"),
        BundledPatchOption(number: 22, filename: "drive-14.3105", packageName: "Siel Com Segundo Passe"),
        BundledPatchOption(number: 23, filename: "drive-15.3105", packageName: "Hs Alto Antena"),
        BundledPatchOption(number: 24, filename: "drive-16.3105", packageName: "Bolsonaro"),
        BundledPatchOption(number: 25, filename: "drive-17.3105", packageName: "MENU FreeFire"),
        BundledPatchOption(number: 26, filename: "drive-18.3105", packageName: "Skin De Pulante")
    ]

    static func option(packageID: UUID) -> BundledPatchOption? {
        switch packageID.uuidString {
        case "70DD849E-F054-4D11-A119-BC4E24E3A39B": return option(for: "drive-01.3105")
        case "2EDE369D-C532-4FCA-A8DE-150505B5015C": return option(for: "drive-02.3105")
        case "6331CC07-5B6F-4812-B8E0-6D55988D2E9D": return option(for: "drive-03.3105")
        case "FACF67C9-0E6D-4721-9B47-6BA1890EB195": return option(for: "drive-04.3105")
        case "54F236BC-AE70-4F97-A986-69AE5C263E34": return option(for: "drive-05.3105")
        case "D337BE6C-4A0C-44B1-9E30-642046D0C3E5": return option(for: "drive-06.3105")
        case "79DCBCD6-36C8-4DDF-A52B-5E0B5BE87F83": return option(for: "drive-07.3105")
        case "5DC51896-3193-4D2E-A1D2-07E8378E4286": return option(for: "drive-08.3105")
        case "8CC42832-0AFE-4D5F-9C96-055D01A18915": return option(for: "drive-09.3105")
        case "7049D4B5-68DD-420D-AD59-54261D40703D": return option(for: "drive-10.3105")
        case "0A7BA733-B479-4638-AA89-A3338B394442": return option(for: "drive-11.3105")
        case "CBE3D164-1FBE-48EE-9D36-0461311B2E2B": return option(for: "drive-12.3105")
        case "E72909C8-D9AA-4DF2-A191-2479C67850CE": return option(for: "drive-13.3105")
        case "970A3ACB-FFCE-47CF-927F-98E6892D48C9": return option(for: "drive-14.3105")
        case "32408D05-AF5C-439E-86E0-E6F0B8634C28": return option(for: "drive-15.3105")
        case "DF00AECE-C5BD-48ED-93B0-37F8A43329B1": return option(for: "drive-16.3105")
        case "AE3D19BE-AF17-4A3C-91FB-E99CA6066BCC": return option(for: "drive-17.3105")
        case "A1C0B50A-9B79-45CD-92E8-87C1F56A396F": return option(for: "drive-18.3105")
        default: return nil
        }
    }

    static func sourceKey(for packageID: UUID) -> String {
        "3105.bundled_patch.source.\(packageID.uuidString)"
    }

    static func option(for filename: String) -> BundledPatchOption? {
        options.first { $0.filename == filename }
    }

    static func option(packageName: String) -> BundledPatchOption? {
        options.first { $0.packageName == packageName }
    }

    static func preferredPackageID(for filename: String) -> UUID? {
        switch filename {
        case "HS PESCOÇO.3105":
            return UUID(uuidString: "4C87975D-5988-4C05-8A6D-158964CA5F5E")
        case "HS 100-.3105":
            return UUID(uuidString: "ABB3E475-F1EE-40D5-858F-4D4C3044716A")
        default:
            return nil
        }
    }
}

private enum BundledPatchBootstrap {
    static func importIfNeeded() {
        let bundledURLs = Bundle.main.urls(
            forResourcesWithExtension: "3105",
            subdirectory: "BundledPatches"
        ) ?? []
        let resourceDirectory = Bundle.main.resourceURL?.appendingPathComponent(
            "BundledPatches",
            isDirectory: true
        )
        let directoryURLs = resourceDirectory.flatMap { directory in
            try? FileManager.default.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: nil,
                options: [.skipsHiddenFiles, .skipsSubdirectoryDescendants]
            )
        } ?? []
        let sources = Array(Set(bundledURLs + directoryURLs))
            .filter { $0.pathExtension.lowercased() == "3105" }
            .sorted { $0.lastPathComponent < $1.lastPathComponent }
        guard !sources.isEmpty else { return }

        var existingIDs = Set(PatchProjectLibrary.load().map(\.id))
        for sourceURL in sources {
            do {
                let data = try PatchProjectLibrary.readPackage(at: sourceURL)
                let summary = try PatchPackageCodec.inspect(data)
                guard !summary.isPasswordProtected else {
                    throw PatchPackageError.invalidProject
                }
                let decoded = try PatchPackageCodec.decode(data, password: nil)
                guard let option = BundledPatchCatalog.option(packageID: summary.packageID)
                    ?? BundledPatchCatalog.option(packageName: decoded.project.name) else { continue }
                let sourceKey = BundledPatchCatalog.sourceKey(for: summary.packageID)
                if existingIDs.contains(summary.packageID) {
                    UserDefaults.standard.set(option.filename, forKey: sourceKey)
                    continue
                }
                // Keep all eight packs available in the library, including packs whose
                // destinations overlap. The transaction layer blocks overlapping applies.
                _ = try PatchProjectLibrary.save(
                    data: data,
                    projectName: decoded.project.name
                )
                existingIDs.insert(summary.packageID)
                UserDefaults.standard.set(option.filename, forKey: sourceKey)
            } catch {
                log("patch: skipped bundled package \(sourceURL.lastPathComponent)")
            }
        }
    }
}

@MainActor
final class PatchProjectStore: ObservableObject {
    @Published private(set) var items: [PatchLibraryItem] = []
    @Published private(set) var isBusy = false
    @Published private(set) var appliedProjectIDs: Set<UUID> = []
    @Published var passwordRequest: PatchPasswordRequest?
    @Published var alert: PatchStoreAlert?
    @Published var unlockErrorKey: String?

    private struct PendingUnlock {
        let data: Data
        let summary: PatchPackageSummary
        let existingURL: URL?
        let origin: PatchPackageOrigin?
    }

    private var pendingUnlock: PendingUnlock?

    init() {
        isBusy = true
        Task.detached(priority: .userInitiated) { [weak self] in
            BundledPatchBootstrap.importIfNeeded()
            let loadedItems = PatchProjectLibrary.load()
            await self?.finishInitialLoad(loadedItems)
        }
    }

    func reload() {
        items = PatchProjectLibrary.load()
        appliedProjectIDs = Set(items.compactMap { item in
            DevicePatchService.latestReceipt(projectID: item.id) == nil ? nil : item.id
        })
    }

    func retryBundledPatches() {
        guard !isBusy else { return }
        isBusy = true
        Task.detached(priority: .userInitiated) { [weak self] in
            BundledPatchBootstrap.importIfNeeded()
            let loadedItems = PatchProjectLibrary.load()
            await self?.finishInitialLoad(loadedItems)
        }
    }

    func isApplied(_ projectID: UUID) -> Bool {
        appliedProjectIDs.contains(projectID)
    }

    func isBundledPatch(_ projectID: UUID) -> Bool {
        guard let filename = UserDefaults.standard.string(
            forKey: BundledPatchCatalog.sourceKey(for: projectID)
        ) else { return false }
        return BundledPatchCatalog.option(for: filename) != nil
    }

    func bundledItem(for option: BundledPatchOption) -> PatchLibraryItem? {
        let candidates = items.filter { item in
            UserDefaults.standard.string(
                forKey: BundledPatchCatalog.sourceKey(for: item.id)
            ) == option.filename
        }
        if let activeItem = candidates.first(where: { isApplied($0.id) }) {
            return activeItem
        }
        if let preferredID = BundledPatchCatalog.preferredPackageID(for: option.filename),
           let preferredItem = items.first(where: { $0.id == preferredID }) {
            return preferredItem
        }
        return candidates.first
    }

    func setBundledPatch(_ projectID: UUID, active: Bool) {
        guard !isBusy,
              let item = items.first(where: { $0.id == projectID }),
              isBundledPatch(projectID) else { return }

        if active {
            guard let project = item.project else {
                present(.invalidProject)
                return
            }
            let activeOthers = items.filter {
                $0.id != projectID
                    && isBundledPatch($0.id)
                    && DevicePatchService.latestReceipt(projectID: $0.id) != nil
            }
            runOperation(successMessageKey: "patch.applied_message") {
                var restoredProjects: [PatchProject] = []
                do {
                    for other in activeOthers {
                        guard let receipt = DevicePatchService.latestReceipt(projectID: other.id) else {
                            continue
                        }
                        try DevicePatchService.restore(receipt: receipt, allowChangedTargets: true)
                        if let otherProject = other.project {
                            restoredProjects.append(otherProject)
                        }
                    }
                    _ = try DevicePatchService.apply(
                        project: project,
                        requireExistingTargets: Self.requiresExistingTargets(for: project.id)
                    )
                } catch {
                    for restoredProject in restoredProjects.reversed() {
                        _ = try? DevicePatchService.apply(
                            project: restoredProject,
                            requireExistingTargets: Self.requiresExistingTargets(for: restoredProject.id)
                        )
                    }
                    throw error
                }
            }
        } else if let receipt = DevicePatchService.latestReceipt(projectID: projectID) {
            runOperation(successMessageKey: "patch.restored_message") {
                try DevicePatchService.restore(receipt: receipt, allowChangedTargets: true)
            }
        }
    }

    private nonisolated static func requiresExistingTargets(for projectID: UUID) -> Bool {
        // MENU installs its two document files; asset patches must match existing game resources.
        projectID.uuidString != "AE3D19BE-AF17-4A3C-91FB-E99CA6066BCC"
    }

    private func finishInitialLoad(_ loadedItems: [PatchLibraryItem]) {
        items = loadedItems
        appliedProjectIDs = Set(loadedItems.compactMap { item in
            DevicePatchService.latestReceipt(projectID: item.id) == nil ? nil : item.id
        })
        isBusy = false
    }

    func create(project: PatchProject, password: String?) {
        runOperation(successMessageKey: "patch.created_message") {
            let encoded = try PatchPackageCodec.encodeNew(project: project, password: password)
            let summary = try PatchPackageCodec.inspect(encoded.data)
            let workspace = try PatchWorkspaceService.createWorkspace(for: project)
            var savedURL: URL?
            do {
                if summary.isPasswordProtected {
                    try PatchKeyStore.store(encoded.contentKey, for: summary)
                }
                savedURL = try PatchProjectLibrary.save(
                    data: encoded.data,
                    projectName: project.name
                )
                try PatchProjectLibrary.markAsAuthorCopy(packageID: project.id)
            } catch {
                try? FileManager.default.removeItem(at: workspace)
                if let savedURL {
                    try? FileManager.default.removeItem(at: savedURL)
                }
                try? PatchKeyStore.delete(for: summary)
                throw error
            }
        }
    }

    func update(project: PatchProject) {
        guard let item = items.first(where: { $0.id == project.id }),
              let contentKey = item.contentKey else {
            present(.invalidProject)
            return
        }
        runOperation(successMessageKey: "patch.updated_message") {
            let original = try PatchProjectLibrary.readPackage(at: item.packageURL)
            let updated = try PatchPackageCodec.update(
                original,
                project: project,
                contentKey: contentKey,
                schemaVersion: PatchPackageCodec.latestSchemaVersion
            )
            _ = try PatchProjectLibrary.save(
                data: updated,
                projectName: project.name,
                existingURL: item.packageURL
            )
        }
    }

    func importPackage(at sourceURL: URL) {
        guard !isBusy else { return }
        isBusy = true
        let hasAccess = sourceURL.startAccessingSecurityScopedResource()
        Task.detached(priority: .userInitiated) { [weak self] in
            defer {
                if hasAccess { sourceURL.stopAccessingSecurityScopedResource() }
            }
            do {
                let data = try PatchProjectLibrary.readPackage(at: sourceURL)
                let summary = try PatchPackageCodec.inspect(data)
                let existingURL = await self?.existingPackageURL(for: summary.packageID)
                if let pending = try Self.persistImportedPackage(
                    data: data,
                    summary: summary,
                    existingURL: existingURL
                ) {
                    await self?.requestPassword(pending: pending)
                } else {
                    await self?.finishOperation(successMessageKey: "patch.imported_message")
                }
            } catch let error as PatchPackageError {
                await self?.failOperation(error)
            } catch {
                await self?.failOperation(.unsupportedFormat)
            }
        }
    }

    @discardableResult
    func importPackage(
        data: Data,
        password: String? = nil,
        origin: PatchPackageOrigin? = nil
    ) -> Bool {
        guard !isBusy else { return false }
        isBusy = true
        Task.detached(priority: .userInitiated) { [weak self] in
            do {
                let summary = try PatchPackageCodec.inspect(data)
                let existingURL = await self?.existingPackageURL(for: summary.packageID)
                if let pending = try Self.persistImportedPackage(
                    data: data,
                    summary: summary,
                    existingURL: existingURL,
                    password: password,
                    origin: origin
                ) {
                    await self?.requestPassword(pending: pending)
                } else {
                    await self?.finishOperation(successMessageKey: "patch.imported_message")
                }
            } catch let error as PatchPackageError {
                await self?.failOperation(error)
            } catch {
                await self?.failOperation(.unsupportedFormat)
            }
        }
        return true
    }

    func presentImportError(_ error: PatchPackageError) {
        present(error)
    }

    func importPackage(from source: PatchImportSource) {
        switch source {
        case .file(let url):
            importPackage(at: url)
        case .remote(let url):
            importPackage(fromRemoteURL: url)
        case .invalid:
            present(.invalidImportLink)
        }
    }

    private func importPackage(fromRemoteURL remoteURL: URL) {
        guard !isBusy,
              PatchImportRoute.validatedRemoteURL(remoteURL) != nil else {
            if !isBusy { present(.invalidImportLink) }
            return
        }
        isBusy = true
        Task.detached(priority: .userInitiated) { [weak self] in
            do {
                let configuration = URLSessionConfiguration.ephemeral
                configuration.timeoutIntervalForRequest = 60
                configuration.timeoutIntervalForResource = 600
                let session = URLSession(configuration: configuration)
                defer { session.invalidateAndCancel() }

                let (temporaryURL, response) = try await session.download(from: remoteURL)
                defer { try? FileManager.default.removeItem(at: temporaryURL) }
                guard let response = response as? HTTPURLResponse,
                      (200..<300).contains(response.statusCode),
                      let finalURL = response.url,
                      PatchImportRoute.validatedRemoteURL(finalURL) != nil else {
                    throw PatchPackageError.remoteImportFailed
                }

                let data = try PatchProjectLibrary.readPackage(at: temporaryURL)
                let summary = try PatchPackageCodec.inspect(data)
                let existingURL = await self?.existingPackageURL(for: summary.packageID)
                if let pending = try Self.persistImportedPackage(
                    data: data,
                    summary: summary,
                    existingURL: existingURL
                ) {
                    await self?.requestPassword(pending: pending)
                } else {
                    await self?.finishOperation(successMessageKey: "patch.imported_message")
                }
            } catch let error as PatchPackageError {
                await self?.failOperation(error)
            } catch {
                await self?.failOperation(.remoteImportFailed)
            }
        }
    }

    func requestUnlock(for item: PatchLibraryItem) {
        guard item.isLocked, !isBusy else { return }
        do {
            let data = try PatchProjectLibrary.readPackage(at: item.packageURL)
            pendingUnlock = PendingUnlock(
                data: data,
                summary: item.summary,
                existingURL: item.packageURL,
                origin: item.origin
            )
            passwordRequest = PatchPasswordRequest(
                summary: item.summary,
                origin: item.origin
            )
        } catch let error as PatchPackageError {
            present(error)
        } catch {
            present(.unsupportedFormat)
        }
    }

    func unlock(password: String) {
        guard let pending = pendingUnlock, !isBusy else { return }
        isBusy = true
        unlockErrorKey = nil
        Task.detached(priority: .userInitiated) { [weak self] in
            do {
                let decoded = try PatchPackageCodec.decode(pending.data, password: password)
                try PatchKeyStore.store(decoded.contentKey, for: pending.summary)
                do {
                    try PatchProjectLibrary.installImportedPackage(
                        data: pending.data,
                        decoded: decoded,
                        summary: pending.summary,
                        existingURL: pending.existingURL,
                        origin: pending.origin
                    )
                } catch {
                    try? PatchKeyStore.delete(for: pending.summary)
                    throw error
                }
                await self?.clearPendingUnlock()
                await self?.finishOperation(successMessageKey: "patch.unlocked_message")
            } catch let error as PatchPackageError {
                await self?.failUnlock(error)
            } catch {
                await self?.failUnlock(.invalidPasswordOrCorruptedPackage)
            }
        }
    }

    func cancelUnlock() {
        clearPendingUnlock()
        isBusy = false
    }

    func clearUnlockError() {
        unlockErrorKey = nil
    }

    func delete(_ item: PatchLibraryItem) {
        do {
            try PatchProjectLibrary.delete(item)
            reload()
        } catch let error as PatchPackageError {
            present(error)
        } catch {
            present(.invalidProject)
        }
    }

    func synchronizeWorkspace(projectID: UUID, reportsSuccess: Bool = false) {
        guard let item = items.first(where: { $0.id == projectID }),
              item.summary.schemaVersion >= 2,
              !isBusy else { return }
        isBusy = true
        Task.detached(priority: .userInitiated) { [weak self] in
            do {
                _ = try PatchProjectLibrary.synchronizeWorkspace(item: item)
                await self?.finishWorkspaceSynchronization(reportsSuccess: reportsSuccess)
            } catch let error as PatchPackageError {
                await self?.failOperation(error)
            } catch {
                await self?.failOperation(.invalidProject)
            }
        }
    }

    private func finishWorkspaceSynchronization(reportsSuccess: Bool) {
        reload()
        isBusy = false
        if reportsSuccess {
            alert = PatchStoreAlert(
                titleKey: "common.done",
                messageKey: "patch.workspace_synced_message"
            )
        }
    }

    private func runOperation(
        successMessageKey: String,
        operation: @escaping () throws -> Void
    ) {
        guard !isBusy else { return }
        isBusy = true
        Task.detached(priority: .userInitiated) { [weak self] in
            do {
                try operation()
                await self?.finishOperation(successMessageKey: successMessageKey)
            } catch let error as PatchPackageError {
                await self?.failOperation(error)
            } catch {
                await self?.failOperation(.invalidProject)
            }
        }
    }

    private func requestPassword(pending: PendingUnlock) {
        pendingUnlock = pending
        passwordRequest = PatchPasswordRequest(
            summary: pending.summary,
            origin: pending.origin
        )
        isBusy = false
    }

    private func existingPackageURL(for packageID: UUID) -> URL? {
        items.first(where: { $0.id == packageID })?.packageURL
    }

    private nonisolated static func persistImportedPackage(
        data: Data,
        summary: PatchPackageSummary,
        existingURL: URL?,
        password: String? = nil,
        origin: PatchPackageOrigin? = nil
    ) throws -> PendingUnlock? {
        if let key = try PatchKeyStore.load(for: summary) {
            let decoded = try PatchPackageCodec.decode(data, contentKey: key)
            try PatchProjectLibrary.installImportedPackage(
                data: data,
                decoded: decoded,
                summary: summary,
                existingURL: existingURL,
                origin: origin
            )
            return nil
        }
        if summary.isPasswordProtected {
            guard let password else {
                return PendingUnlock(
                    data: data,
                    summary: summary,
                    existingURL: existingURL,
                    origin: origin
                )
            }
            let decoded = try PatchPackageCodec.decode(data, password: password)
            try PatchKeyStore.store(decoded.contentKey, for: summary)
            do {
                try PatchProjectLibrary.installImportedPackage(
                    data: data,
                    decoded: decoded,
                    summary: summary,
                    existingURL: existingURL,
                    origin: origin
                )
            } catch {
                try? PatchKeyStore.delete(for: summary)
                throw error
            }
            return nil
        }
        let decoded = try PatchPackageCodec.decode(data, password: nil)
        try PatchProjectLibrary.installImportedPackage(
            data: data,
            decoded: decoded,
            summary: summary,
            existingURL: existingURL,
            origin: origin
        )
        return nil
    }

    private func clearPendingUnlock() {
        pendingUnlock = nil
        passwordRequest = nil
        unlockErrorKey = nil
    }

    private func finishOperation(successMessageKey: String) {
        reload()
        isBusy = false
        alert = PatchStoreAlert(titleKey: "common.done", messageKey: successMessageKey)
    }

    private func failOperation(_ error: PatchPackageError) {
        reload()
        isBusy = false
        present(error)
    }

    private func failUnlock(_ error: PatchPackageError) {
        isBusy = false
        // Keep the password sheet open so the user can retry.
        // Presenting an alert while dismissing the sheet swallows the message.
        if case .invalidPasswordOrCorruptedPackage = error {
            unlockErrorKey = "patch.error.wrong_password"
        } else {
            unlockErrorKey = error.localizationKey
        }
    }

    private func present(_ error: PatchPackageError) {
        alert = PatchStoreAlert(
            titleKey: "common.failed",
            messageKey: error.localizationKey,
            messageArgument: error.localizationArgument
        )
    }
}
