import Foundation

enum CheckError: Error { case failed(String), injectedFailure }
func check(_ condition: @autoclosure () throws -> Bool, _ message: String) throws {
    if try !condition() { throw CheckError.failed(message) }
}
let fm = FileManager.default
let root = fm.temporaryDirectory.appendingPathComponent("3105-restore-checks-\(UUID().uuidString)")
try fm.createDirectory(at: root, withIntermediateDirectories: true)
defer { try? fm.removeItem(at: root) }
let container = root.appendingPathComponent("container")
let backups = root.appendingPathComponent("backups")
try fm.createDirectory(at: container.appendingPathComponent("Documents"), withIntermediateDirectories: true)
let existing = container.appendingPathComponent("Documents/original.bin")
let created = container.appendingPathComponent("Documents/created.bin")
let original = Data([0, 255, 10, 42, 0, 100])
let replacement = Data("replacement".utf8)
let newContent = Data("new-file".utf8)
let project = PatchProject(name: "restore-check", rules: [
    PatchRule(bundleID: "test.application", relativePath: "Documents/original.bin", replacementFilename: "original.bin", replacementData: replacement),
    PatchRule(bundleID: "test.application", relativePath: "Documents/created.bin", replacementFilename: "created.bin", replacementData: newContent)
])
func apply() throws -> PatchTransactionReceipt {
    try PatchTransaction.apply(project: project, backupRoot: backups, containerResolver: { _ in container })
}
func restore(_ receipt: PatchTransactionReceipt, beforeWrite: ((Int) throws -> Void)? = nil) throws {
    try PatchTransaction.restore(receipt: receipt, allowChangedTargets: true, containerResolver: { _ in container }, beforeWrite: beforeWrite)
}
try original.write(to: existing)

// The game's modifications do not prevent an explicitly requested restore.
for _ in 0..<3 {
    let receipt = try apply()
    try check(Data(contentsOf: existing) == replacement, "replacement not applied")
    try check(Data(contentsOf: created) == newContent, "new file not created")
    try Data("changed-by-game".utf8).write(to: existing)
    try restore(receipt)
    try check(Data(contentsOf: existing) == original, "original bytes not restored")
    try check(!fm.fileExists(atPath: created.path), "injected new file not removed")
    try check(PatchTransaction.latestReceipt(projectID: project.id, backupRoot: backups) == nil, "inactive transaction still marked active")
}
print("PASS: repeated apply/restore, modified target, exact original bytes, created-file removal")

// A missing patched file is recreated from its verified original backup.
let missingReceipt = try apply()
try fm.removeItem(at: existing)
try restore(missingReceipt)
try check(Data(contentsOf: existing) == original, "missing original was not recovered")
try check(!fm.fileExists(atPath: created.path), "created file survived missing-target restore")
print("PASS: missing target recovered from backup")

// Partial restore failure must recover the patched state and retain its receipt.
let interrupted = try apply()
do {
    try restore(interrupted, beforeWrite: { if $0 == 1 { throw CheckError.injectedFailure } })
    throw CheckError.failed("injected failure was ignored")
} catch CheckError.failed(let reason) { throw CheckError.failed(reason) }
catch { }
try check(Data(contentsOf: existing) == replacement, "failed restore left partial original state")
try check(Data(contentsOf: created) == newContent, "failed restore did not recover created file")
try check(PatchTransaction.latestReceipt(projectID: project.id, backupRoot: backups) != nil, "failed restore lost active receipt")
try restore(interrupted)
try check(Data(contentsOf: existing) == original, "retry did not restore original")
print("PASS: interrupted restore rollback and successful retry")

// Corrupted originals must never be copied over the target.
let corruptReceipt = try apply()
let journal = try PropertyListSerialization.propertyList(from: Data(contentsOf: corruptReceipt.journalURL), format: nil) as! [String: Any]
let records = journal["records"] as! [[String: Any]]
let originalRecord = records.first { ($0["originalExisted"] as? Bool) == true }!
let backup = corruptReceipt.journalURL.deletingLastPathComponent().appendingPathComponent(originalRecord["backupFilename"] as! String)
try Data("corrupted".utf8).write(to: backup)
var refused = false
do { try restore(corruptReceipt) } catch { refused = true }
try check(refused, "corrupted backup accepted")
try check(Data(contentsOf: existing) == replacement, "corrupted restore modified existing target")
try check(Data(contentsOf: created) == newContent, "corrupted restore removed new target")
try check(PatchTransaction.latestReceipt(projectID: project.id, backupRoot: backups) != nil, "corrupted backup cleared active status")
print("PASS: corrupted backup rejected without clearing active status")
