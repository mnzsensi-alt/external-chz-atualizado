# 3105 Workspace

Aplicativo iOS independente para trabalhar em sua própria pasta de documentos e em pastas escolhidas pelo seletor do iOS. Não contém Filza, `worse_query`, exploração de kernel, escape de sandbox, SSH, servidores ou APIs privadas de descoberta de apps.

## Funções

- Navegação por pastas, visualização com Quick Look e compartilhamento de arquivos.
- Importação de arquivos, criação de pastas e acesso persistente por bookmarks às pastas escolhidas.
- Importação e exportação de pacotes .3105, incluindo pacotes protegidos por senha.
- Escolha explícita de uma pasta de destino para cada alvo do pacote.
- Um patch ativo por vez; backup anterior à aplicação e restauração com verificação de hash.
- Arquivos criados pelo patch são removidos ao restaurar; falhas não anunciam sucesso.
- Exemplo completo em exemplo.txt para testar aplicar/restaurar no próprio espaço do app.

## Compilar

Abra `Workspace3105.xcodeproj` no Xcode e selecione o scheme Workspace3105. Ajuste a equipe de assinatura e o identificador para sua conta antes de instalar em dispositivo. Para gerar um arquivo sem assinatura:

```sh
xcodebuild -project Workspace3105.xcodeproj -scheme Workspace3105 -configuration Release -destination 'generic/platform=iOS' -archivePath build/Workspace3105.xcarchive CODE_SIGNING_ALLOWED=NO archive
```

Os testes usam os arquivos reais do núcleo, em pastas temporárias no macOS:

```sh
xcrun swiftc -o /tmp/workspace-tests Sources/Core/PatchProjectModels.swift Sources/Core/PatchTransaction.swift Sources/Core/PatchPackageCodec.swift Sources/CoordinatedWorkspace.swift tests/RestorationChecks/main.swift
/tmp/workspace-tests
```

## Testar no app

Em Patches, carregue o exemplo, abra o pacote e escolha Pasta do app para o destino. Aplique e visualize exemplo.txt em Arquivos. Restaure e confirme o conteúdo original. Para documentos externos, escolha a pasta na aba Pastas e selecione-a no destino do pacote.

O acesso depende do que o seletor do iOS permite escolher. Este projeto não dá acesso automático aos dados privados de outros apps. Bookmarks e coordenação de arquivos seguem o mecanismo público descrito na [documentação da Apple](https://developer.apple.com/documentation/uikit/providing-access-to-directories).

Backups ficam no Application Support do app. Apagar o app também apaga esses backups. Senhas não são salvas; pacotes protegidos precisam ser desbloqueados novamente a cada sessão. Uma restauração usa o original salvo antes da aplicação e não pode reconstruir um backup perdido.

## Licença e créditos

GPL-3.0. O núcleo PatchProjectModels, PatchPackageCodec e PatchTransaction, e o ícone, foram reaproveitados do projeto 3105 fornecido nesta conversa (autoria e créditos originais de YangJiii e colaboradores). A interface e a camada de pastas autorizadas foram adicionadas para esta versão. O código e os binários de Filza/JBJFLab não são incluídos.
