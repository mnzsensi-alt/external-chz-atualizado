import Foundation
import SwiftUI

struct FolderGrant: Codable, Identifiable, Hashable {
    let id: String
    var name: String
    var bookmark: Data
}

struct SavedPackage: Codable, Identifiable {
    let id: UUID
    var name: String
    var targets: [String]
    var destinations: [String: String]
}

struct WorkspaceFile: Identifiable {
    var id: String { url.path }
    let url: URL
    let isDirectory: Bool
    let size: Int64
}

struct WorkspaceMessage: Identifiable {
    let id = UUID()
    let title: String
    let text: String
}

struct WorkspaceRoot: Identifiable {
    let id: String
    let name: String
}

enum WorkspaceError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        if case .message(let text) = self { return text }
        return nil
    }
}

final class FolderSessions {
    private var scopes: [String: URL] = [:]
    func open(_ url: URL, id: String) {
        if let previous = scopes.removeValue(forKey: id) { previous.stopAccessingSecurityScopedResource() }
        if url.startAccessingSecurityScopedResource() { scopes[id] = url }
    }
    func close(_ id: String) { scopes.removeValue(forKey: id)?.stopAccessingSecurityScopedResource() }
    deinit { for url in scopes.values { url.stopAccessingSecurityScopedResource() } }
}

@MainActor
final class WorkspaceStore: ObservableObject {
    @Published private(set) var grants: [FolderGrant] = []
    @Published private(set) var packages: [SavedPackage] = []
    @Published private(set) var active: Set<UUID> = []
    @Published private(set) var busy = false
    @Published var message: WorkspaceMessage?
    @Published var pendingPassword = false
    private var pendingData: Data?
    private var projects: [UUID: PatchProject] = [:]
    private var urls: [String: URL] = [:]
    private let sessions = FolderSessions()
    let localRoot: URL
    let stateRoot: URL
    let backupRoot: URL
    private let packageRoot: URL

    init() {
        let fm = FileManager.default
        localRoot = fm.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Workspace", isDirectory: true)
        stateRoot = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Workspace3105", isDirectory: true)
        backupRoot = stateRoot.appendingPathComponent("Backups", isDirectory: true)
        packageRoot = stateRoot.appendingPathComponent("Packages", isDirectory: true)
        do {
            for url in [localRoot, stateRoot, backupRoot, packageRoot] {
                try fm.createDirectory(at: url, withIntermediateDirectories: true)
            }
            urls["local"] = localRoot
            if let data = try? Data(contentsOf: stateRoot.appendingPathComponent("folders.json")) {
                grants = try JSONDecoder().decode([FolderGrant].self, from: data)
            }
            if let data = try? Data(contentsOf: stateRoot.appendingPathComponent("packages.json")) {
                packages = try JSONDecoder().decode([SavedPackage].self, from: data)
            }
            var staleNames: [String] = []
            for index in grants.indices {
                do {
                    var stale = false
                    let url = try URL(resolvingBookmarkData: grants[index].bookmark, options: .withoutUI, relativeTo: nil, bookmarkDataIsStale: &stale)
                    sessions.open(url, id: grants[index].id)
                    urls[grants[index].id] = url
                    if stale { grants[index].bookmark = try url.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil) }
                } catch { staleNames.append(grants[index].name) }
            }
            try persist()
            for item in packages {
                if let data = try? Data(contentsOf: packageURL(item.id)),
                   let decoded = try? PatchPackageCodec.decode(data, password: nil) { projects[item.id] = decoded.project }
            }
            refreshActive()
            if !UserDefaults.standard.bool(forKey: "workspace.demo.initialized") {
                try Data("Arquivo original de exemplo.\n".utf8).write(to: localRoot.appendingPathComponent("exemplo.txt"))
                UserDefaults.standard.set(true, forKey: "workspace.demo.initialized")
            }
            if !staleNames.isEmpty { show("Pastas indisponíveis", "Selecione novamente: " + staleNames.joined(separator: ", ")) }
        } catch { report(error) }
    }

    var roots: [WorkspaceRoot] { [WorkspaceRoot(id: "local", name: "Pasta do app")] + grants.map { WorkspaceRoot(id: $0.id, name: $0.name) } }
    func rootURL(_ id: String) -> URL? { urls[id] }
    func project(_ id: UUID) -> PatchProject? { projects[id] }
    func packageURL(_ id: UUID) -> URL { packageRoot.appendingPathComponent(id.uuidString + ".3105") }
    func isActive(_ id: UUID) -> Bool { active.contains(id) }
    func folderName(_ id: String) -> String { roots.first { $0.id == id }?.name ?? "Pasta indisponível" }

    func addFolder(_ url: URL) {
        guard !busy else { return }
        guard grants.count < 12 else { show("Limite de pastas", "Remova uma pasta da lista antes de adicionar outra."); return }
        let id = UUID().uuidString
        sessions.open(url, id: id)
        do {
            let bookmark = try url.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil)
            grants.append(FolderGrant(id: id, name: url.lastPathComponent, bookmark: bookmark))
            urls[id] = url
            try persist()
        } catch { sessions.close(id); report(error) }
    }

    func removeFolder(_ id: String) {
        guard !busy else { return }
        guard !packages.contains(where: { active.contains($0.id) && $0.destinations.values.contains(id) }) else {
            show("Patch ativo nesta pasta", "Restaure os arquivos antes de remover esta pasta da lista."); return
        }
        grants.removeAll { $0.id == id }
        urls.removeValue(forKey: id)
        sessions.close(id)
        for index in packages.indices { packages[index].destinations = packages[index].destinations.filter { $0.value != id } }
        do { try persist() } catch { report(error) }
    }

    func reconnectFolder(_ url: URL, id: String) {
        guard !busy, let index = grants.firstIndex(where: { $0.id == id }) else { return }
        do {
            let bookmark = try url.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil)
            sessions.open(url, id: id)
            grants[index].bookmark = bookmark
            grants[index].name = url.lastPathComponent
            urls[id] = url
            try persist()
        } catch { report(error) }
    }

    func setDestination(packageID: UUID, target: String, rootID: String) {
        guard !busy, !active.contains(packageID), let index = packages.firstIndex(where: { $0.id == packageID }) else { return }
        let previous = packages[index].destinations
        packages[index].destinations[target] = rootID.isEmpty ? nil : rootID
        do { try persist() } catch { packages[index].destinations = previous; report(error) }
    }

    func canApply(_ item: SavedPackage) -> Bool {
        !busy && projects[item.id] != nil && active.isEmpty
            && item.targets.allSatisfy { target in item.destinations[target].flatMap { urls[$0] } != nil }
            && Set(resolvedDestinations(item).values.map { $0.standardizedFileURL.path }).count == item.targets.count
    }

    func loadDemo() {
        guard let url = Bundle.main.url(forResource: "Demo", withExtension: "3105") else { return }
        importPackage(url)
    }

    func importPackage(_ url: URL) {
        guard !busy else { return }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size <= 100 * 1024 * 1024 else { throw WorkspaceError.message("O pacote excede o limite de 100 MB.") }
            let data = try Data(contentsOf: url)
            let summary = try PatchPackageCodec.inspect(data)
            guard !active.contains(summary.packageID) else { throw WorkspaceError.message("Restaure o patch ativo antes de importar outra versão.") }
            if summary.isPasswordProtected { pendingData = data; pendingPassword = true }
            else { try install(data, password: nil) }
        } catch { report(error) }
    }

    func unlock(_ password: String) -> String? {
        guard let data = pendingData else { return "Importe o pacote novamente." }
        do {
            try install(data, password: password)
            pendingData = nil
            pendingPassword = false
            return nil
        } catch { return readableError(error) }
    }
    func cancelUnlock() { pendingData = nil; pendingPassword = false }

    private func install(_ data: Data, password: String?) throws {
        let decoded = try PatchPackageCodec.decode(data, password: password)
        let project = decoded.project
        try data.write(to: packageURL(project.id), options: .atomic)
        if let index = packages.firstIndex(where: { $0.id == project.id }) {
            packages[index].name = project.name
            packages[index].targets = project.allBundleIdentifiers
        } else {
            packages.append(SavedPackage(id: project.id, name: project.name, targets: project.allBundleIdentifiers, destinations: [:]))
        }
        projects[project.id] = project
        try persist()
    }

    func apply(_ item: SavedPackage) {
        guard canApply(item), let project = projects[item.id] else { return }
        let roots = resolvedDestinations(item)
        let backups = backupRoot
        run(success: "Patch aplicado. O backup dos arquivos anteriores foi salvo.") {
            try CoordinatedWorkspace.write(roots: roots) { coordinated in
                _ = try PatchTransaction.apply(project: project, backupRoot: backups, containerResolver: { target in
                    guard let url = coordinated[target] else { throw WorkspaceError.message("Selecione a pasta de destino.") }
                    return url
                })
            }
        }
    }

    func restore(_ item: SavedPackage) {
        guard !busy, let receipt = PatchTransaction.latestReceipt(projectID: item.id, backupRoot: backupRoot) else { return }
        let roots = resolvedDestinations(item)
        run(success: "Originais restaurados e verificados. Os arquivos novos do patch foram removidos.") {
            try CoordinatedWorkspace.write(roots: roots) { coordinated in
                try PatchTransaction.restore(receipt: receipt, allowChangedTargets: true, containerResolver: { target in
                    guard let url = coordinated[target] else { throw WorkspaceError.message("A pasta original está indisponível. Selecione-a novamente.") }
                    return url
                })
            }
        }
    }

    func removePackage(_ item: SavedPackage) {
        guard !busy, !active.contains(item.id) else { return }
        do {
            try FileManager.default.removeItem(at: packageURL(item.id))
            packages.removeAll { $0.id == item.id }
            projects.removeValue(forKey: item.id)
            try persist()
        } catch { report(error) }
    }

    private func resolvedDestinations(_ item: SavedPackage) -> [String: URL] {
        item.destinations.reduce(into: [:]) { result, pair in if let url = urls[pair.value] { result[pair.key] = url } }
    }

    private func run(success: String, operation: @escaping @Sendable () throws -> Void) {
        guard !busy else { return }
        busy = true
        Task {
            do {
                try await Task.detached(priority: .userInitiated) { try operation() }.value
                refreshActive()
                busy = false
                show("Concluído", success)
            } catch { refreshActive(); busy = false; report(error) }
        }
    }

    private func refreshActive() {
        active = Set(packages.compactMap { PatchTransaction.latestReceipt(projectID: $0.id, backupRoot: backupRoot) == nil ? nil : $0.id })
    }

    private func persist() throws {
        try JSONEncoder().encode(grants).write(to: stateRoot.appendingPathComponent("folders.json"), options: .atomic)
        try JSONEncoder().encode(packages).write(to: stateRoot.appendingPathComponent("packages.json"), options: .atomic)
    }
    func show(_ title: String, _ text: String) { message = WorkspaceMessage(title: title, text: text) }
    func report(_ error: Error) { show("Não foi possível concluir", readableError(error)) }
    private func readableError(_ error: Error) -> String {
        guard let patchError = error as? PatchPackageError else { return error.localizedDescription }
        switch patchError {
        case .invalidPasswordOrCorruptedPackage: return "Senha incorreta ou pacote corrompido. Confira a senha e tente novamente."
        case .unsupportedFormat, .unsupportedVersion: return "Este arquivo não é um pacote .3105 compatível."
        case .targetOccupied(let path): return "Outro patch está usando este destino: \(path). Restaure-o primeiro."
        case .targetFileMissing(let path): return "Arquivo de destino não encontrado: \(path)."
        case .projectAlreadyApplied: return "Este patch já está aplicado. Restaure os originais antes de aplicar novamente."
        case .restoreFailed, .restoreTargetsChanged: return "Não foi possível restaurar todos os arquivos. O backup foi preservado; confira a disponibilidade da pasta de destino."
        case .applyFailed: return "A aplicação falhou. Confira a pasta de destino e o espaço disponível. Os backups da operação foram preservados."
        case .symbolicLinkUnsupported, .unsafeTargetPath: return "O pacote contém um caminho que não pode ser usado nesta pasta."
        case .sizeLimitExceeded: return "O pacote excede o tamanho permitido."
        case .invalidBundleIdentifier, .duplicateTarget, .invalidProject: return "O pacote contém destinos ou arquivos inválidos."
        default: return "Não foi possível processar este pacote. Confira o arquivo e a pasta de destino."
        }
    }

    func files(rootID: String, relativePath: String) throws -> [WorkspaceFile] {
        guard let root = urls[rootID] else { throw WorkspaceError.message("Selecione novamente a pasta no seletor do iOS.") }
        let folder = relativePath.isEmpty ? root : try PatchPathValidator.resolveContainedTargetURL(relativePath: relativePath, containerRoot: root)
        let contents = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey, .fileSizeKey], options: [.skipsHiddenFiles])
        return try contents.compactMap { url -> WorkspaceFile? in
            let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey, .fileSizeKey])
            guard values.isSymbolicLink != true else { return nil }
            return WorkspaceFile(url: url, isDirectory: values.isDirectory == true, size: Int64(values.fileSize ?? 0))
        }.sorted { $0.isDirectory == $1.isDirectory ? $0.url.lastPathComponent.localizedStandardCompare($1.url.lastPathComponent) == .orderedAscending : $0.isDirectory }
    }

    func importFiles(_ incoming: [URL], rootID: String, relativePath: String) {
        guard !busy, let root = urls[rootID] else { return }
        do {
            let folder = relativePath.isEmpty ? root : try PatchPathValidator.resolveContainedTargetURL(relativePath: relativePath, containerRoot: root)
            for url in incoming {
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                let destination = folder.appendingPathComponent(url.lastPathComponent)
                guard !FileManager.default.fileExists(atPath: destination.path) else { throw WorkspaceError.message("Já existe um arquivo chamado \(url.lastPathComponent).") }
                try FileManager.default.copyItem(at: url, to: destination)
            }
        } catch { report(error) }
    }

    func createFolder(_ name: String, rootID: String, relativePath: String) {
        guard !busy, let root = urls[rootID] else { return }
        do {
            guard !name.isEmpty, !name.contains("/"), !name.contains("\\"), name != ".", name != ".." else { throw WorkspaceError.message("Use um nome de pasta sem barras.") }
            let parent = relativePath.isEmpty ? root : try PatchPathValidator.resolveContainedTargetURL(relativePath: relativePath, containerRoot: root)
            try FileManager.default.createDirectory(at: parent.appendingPathComponent(name), withIntermediateDirectories: false)
        } catch { report(error) }
    }
}
