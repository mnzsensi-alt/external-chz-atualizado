import Foundation

enum CoordinatedWorkspace {
    static func write(roots: [String: URL], operation: ([String: URL]) throws -> Void) throws {
        let unique = Dictionary(grouping: roots.values, by: { $0.standardizedFileURL.path })
            .compactMap { $0.value.first }.sorted { $0.path < $1.path }
        func coordinate(_ index: Int, _ resolved: [String: URL]) throws {
            guard index < unique.count else { try operation(resolved); return }
            let original = unique[index]
            var coordinationError: NSError?
            var operationError: Error?
            NSFileCoordinator().coordinate(writingItemAt: original, options: .forMerging, error: &coordinationError) { coordinated in
                var next = resolved
                for pair in roots where pair.value.standardizedFileURL.path == original.standardizedFileURL.path { next[pair.key] = coordinated }
                do { try coordinate(index + 1, next) } catch { operationError = error }
            }
            if let operationError { throw operationError }
            if let coordinationError { throw coordinationError }
        }
        try coordinate(0, roots)
    }
}
