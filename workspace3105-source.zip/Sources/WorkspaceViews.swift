import SwiftUI
import UniformTypeIdentifiers
import QuickLook

struct WorkspaceHome: View {
    @EnvironmentObject private var store: WorkspaceStore
    var body: some View {
        TabView {
            NavigationStack { BrowserRoot() }
                .tabItem { Label("Arquivos", systemImage: "folder") }
            NavigationStack { PackageLibrary() }
                .tabItem { Label("Patches", systemImage: "square.stack.3d.up") }
            NavigationStack { FolderLibrary() }
                .tabItem { Label("Pastas", systemImage: "folder.badge.plus") }
        }
        .alert(item: $store.message) { message in
            Alert(title: Text(message.title), message: Text(message.text), dismissButton: .default(Text("OK")))
        }
        .sheet(isPresented: $store.pendingPassword, onDismiss: { store.cancelUnlock() }) {
            PackagePasswordView()
        }
        .overlay(alignment: .bottomTrailing) {
            if store.busy {
                ProgressView().padding(14).background(.ultraThinMaterial, in: Capsule()).padding(.bottom, 64).padding(.trailing, 16)
            }
        }
    }
}

struct BrowserRoot: View {
    @EnvironmentObject private var store: WorkspaceStore
    @State private var selected = "local"
    var body: some View {
        VStack(spacing: 0) {
            Picker("Pasta", selection: $selected) {
                ForEach(store.roots, id: \.id) { root in Text(root.name).tag(root.id) }
            }.pickerStyle(.menu).padding(.horizontal)
            FolderBrowser(rootID: selected, relativePath: "").id(selected)
        }
        .navigationTitle("3105 Workspace")
        .onChange(of: store.grants) { _ in if store.rootURL(selected) == nil { selected = "local" } }
    }
}

struct FolderBrowser: View {
    @EnvironmentObject private var store: WorkspaceStore
    let rootID: String
    let relativePath: String
    @State private var entries: [WorkspaceFile] = []
    @State private var errorText: String?
    @State private var importing = false
    @State private var naming = false
    @State private var folderName = ""
    @State private var preview: WorkspaceFile?

    var body: some View {
        Group {
            if let errorText {
                ContentUnavailableView("Pasta indisponível", systemImage: "folder.badge.questionmark", description: Text(errorText))
            } else if entries.isEmpty {
                ContentUnavailableView("Pasta vazia", systemImage: "folder", description: Text("Importe arquivos ou crie uma pasta pelo menu acima."))
            } else {
                List(entries) { entry in
                    if entry.isDirectory {
                        NavigationLink {
                            FolderBrowser(rootID: rootID, relativePath: childPath(entry.url.lastPathComponent))
                                .navigationTitle(entry.url.lastPathComponent)
                        } label: { fileLabel(entry) }
                    } else {
                        Button { preview = entry } label: { fileLabel(entry) }
                            .contextMenu {
                                ShareLink(item: entry.url) { Label("Compartilhar", systemImage: "square.and.arrow.up") }
                                if entry.url.pathExtension.lowercased() == "3105" {
                                    Button("Importar patch") { store.importPackage(entry.url) }
                                }
                            }
                    }
                }.listStyle(.plain)
            }
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("Importar arquivos", systemImage: "square.and.arrow.down") { importing = true }
                    Button("Nova pasta", systemImage: "folder.badge.plus") { naming = true }
                    Button("Atualizar", systemImage: "arrow.clockwise") { reload() }
                } label: { Image(systemName: "ellipsis.circle") }
                .disabled(store.busy)
            }
        }
        .onAppear { reload() }
        .onChange(of: store.busy) { busy in if !busy { reload() } }
        .refreshable { reload() }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.item], allowsMultipleSelection: true) { result in
            do { store.importFiles(try result.get(), rootID: rootID, relativePath: relativePath); reload() }
            catch { store.report(error) }
        }
        .alert("Nova pasta", isPresented: $naming) {
            TextField("Nome", text: $folderName)
            Button("Criar") { store.createFolder(folderName, rootID: rootID, relativePath: relativePath); folderName = ""; reload() }
            Button("Cancelar", role: .cancel) { folderName = "" }
        }
        .sheet(item: $preview) { entry in FilePreview(url: entry.url) }
    }

    private func childPath(_ name: String) -> String { relativePath.isEmpty ? name : relativePath + "/" + name }
    private func fileLabel(_ entry: WorkspaceFile) -> some View {
        HStack(spacing: 12) {
            Image(systemName: entry.isDirectory ? "folder.fill" : "doc.fill").foregroundStyle(entry.isDirectory ? Color.orange : Color.secondary).frame(width: 28)
            VStack(alignment: .leading, spacing: 3) {
                Text(entry.url.lastPathComponent).foregroundStyle(.primary).lineLimit(2)
                if !entry.isDirectory { Text(ByteCountFormatter.string(fromByteCount: entry.size, countStyle: .file)).font(.caption).foregroundStyle(.secondary) }
            }
        }.padding(.vertical, 4)
    }
    private func reload() {
        do { entries = try store.files(rootID: rootID, relativePath: relativePath); errorText = nil }
        catch { entries = []; errorText = error.localizedDescription }
    }
}

struct PackageLibrary: View {
    @EnvironmentObject private var store: WorkspaceStore
    @State private var importing = false
    var body: some View {
        List {
            Section {
                Text("Aplique pacotes em arquivos do app ou em pastas escolhidas por você. Selecione o destino antes de aplicar.")
                    .font(.subheadline).foregroundStyle(.secondary)
                Button("Carregar exemplo", systemImage: "sparkles") { store.loadDemo() }
            }
            Section("Seus pacotes") {
                if store.packages.isEmpty { Text("Importe um arquivo .3105 para começar.").foregroundStyle(.secondary) }
                ForEach(store.packages) { item in
                    NavigationLink { PackageDetail(id: item.id) } label: {
                        HStack {
                            Image(systemName: store.isActive(item.id) ? "checkmark.circle.fill" : "shippingbox").foregroundStyle(.orange)
                            VStack(alignment: .leading) {
                                Text(item.name)
                                Text(store.isActive(item.id) ? "Aplicado · backup disponível" : "Pronto para configurar").font(.caption).foregroundStyle(.secondary)
                            }
                        }.padding(.vertical, 5)
                    }
                }
            }
        }
        .navigationTitle("Patches")
        .toolbar { Button("Importar", systemImage: "plus") { importing = true }.disabled(store.busy) }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.data], allowsMultipleSelection: false) { result in
            do { if let url = try result.get().first { store.importPackage(url) } }
            catch { store.report(error) }
        }
    }
}

struct PackageDetail: View {
    @EnvironmentObject private var store: WorkspaceStore
    @Environment(\.dismiss) private var dismiss
    let id: UUID
    @State private var removing = false
    var body: some View {
        Group {
            if let item = store.packages.first(where: { $0.id == id }) {
                Form {
                    Section {
                        Label(store.isActive(id) ? "Aplicado" : "Não aplicado", systemImage: store.isActive(id) ? "checkmark.circle.fill" : "circle")
                        Text("O backup é salvo antes da aplicação. Restaurar recupera os arquivos anteriores e remove os arquivos novos criados pelo pacote.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    Section("Destinos") {
                        ForEach(item.targets, id: \.self) { target in
                            Picker(target, selection: Binding(
                                get: { item.destinations[target] ?? "" },
                                set: { store.setDestination(packageID: id, target: target, rootID: $0) }
                            )) {
                                Text("Escolha uma pasta").tag("")
                                ForEach(store.roots, id: \.id) { root in Text(root.name).tag(root.id) }
                            }.disabled(store.isActive(id) || store.busy)
                        }
                        Text("Escolha a pasta que contém os caminhos listados abaixo. Cada destino deve usar uma pasta diferente. Adicione pastas externas na aba Pastas.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    if let project = store.project(id) {
                        Section("Arquivos do pacote") {
                            ForEach(project.rules) { rule in
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(rule.relativePath).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                                    Text(ByteCountFormatter.string(fromByteCount: Int64(rule.replacementData.count), countStyle: .file)).font(.caption2).foregroundStyle(.secondary)
                                }
                            }
                        }
                    } else {
                        Section { Text("Pacote protegido. Importe-o novamente e informe a senha para aplicar. A restauração do backup não exige a senha do pacote.").font(.footnote) }
                    }
                    Section {
                        if store.isActive(id) {
                            Button("Restaurar originais", systemImage: "arrow.uturn.backward") { store.restore(item) }.disabled(store.busy)
                        } else {
                            Button("Aplicar patch", systemImage: "checkmark") { store.apply(item) }.disabled(!store.canApply(item))
                            if !store.active.isEmpty { Text("Restaure o patch ativo antes de aplicar outro.").font(.footnote).foregroundStyle(.secondary) }
                        }
                        ShareLink(item: store.packageURL(id)) { Label("Exportar pacote", systemImage: "square.and.arrow.up") }
                        Button("Remover da biblioteca", role: .destructive) { removing = true }.disabled(store.isActive(id) || store.busy)
                    }
                }.navigationTitle(item.name)
                    .confirmationDialog("Remover este pacote da biblioteca?", isPresented: $removing, titleVisibility: .visible) {
                        Button("Remover", role: .destructive) { store.removePackage(item); dismiss() }
                    }
            } else { ContentUnavailableView("Pacote removido", systemImage: "shippingbox") }
        }
    }
}

struct FolderLibrary: View {
    @EnvironmentObject private var store: WorkspaceStore
    @State private var choosing = false
    @State private var reconnectID: String?
    var body: some View {
        List {
            Section {
                Label("Pasta do app", systemImage: "folder.fill")
                Text("Disponível também no app Arquivos, em No Meu iPhone → 3105 Workspace → Workspace.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Pastas escolhidas") {
                ForEach(store.grants) { folder in
                    VStack(alignment: .leading, spacing: 4) {
                        Label(folder.name, systemImage: "folder")
                        if store.rootURL(folder.id) == nil { Text("Pasta indisponível").font(.caption).foregroundStyle(.orange) }
                        Button("Reconectar pasta") { reconnectID = folder.id; choosing = true }.font(.caption).disabled(store.busy)
                        Button("Remover da lista", role: .destructive) { store.removeFolder(folder.id) }.font(.caption).disabled(store.busy)
                    }
                }
                Button("Adicionar pasta", systemImage: "folder.badge.plus") { reconnectID = nil; choosing = true }.disabled(store.busy)
            }
            Section("Como testar") {
                Text("1. Em Patches, toque em Carregar exemplo.\n2. Abra o pacote e escolha Pasta do app como destino.\n3. Aplique e confira exemplo.txt na aba Arquivos.\n4. Restaure e confira o conteúdo original.")
                    .font(.subheadline)
            }
        }.navigationTitle("Pastas")
            .sheet(isPresented: $choosing) {
                FolderPicker { url in
                    if let id = reconnectID { store.reconnectFolder(url, id: id) } else { store.addFolder(url) }
                    choosing = false
                }
            }
    }
}

struct PackagePasswordView: View {
    @EnvironmentObject private var store: WorkspaceStore
    @State private var password = ""
    @State private var passwordError: String?
    var body: some View {
        NavigationStack {
            Form {
                SecureField("Senha do pacote", text: $password)
                if let passwordError { Text(passwordError).font(.footnote).foregroundStyle(.red) }
                Button("Importar") { passwordError = store.unlock(password) }.disabled(password.isEmpty)
                Text("A senha não é salva. Pacotes protegidos precisam ser desbloqueados novamente após fechar o app.").font(.footnote).foregroundStyle(.secondary)
            }.navigationTitle("Pacote protegido")
                .toolbar { Button("Cancelar") { store.cancelUnlock() } }
        }
    }
}

struct FolderPicker: UIViewControllerRepresentable {
    let selected: (URL) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(selected) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.folder], asCopy: false)
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        return picker
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let selected: (URL) -> Void
        init(_ selected: @escaping (URL) -> Void) { self.selected = selected }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { if let url = urls.first { selected(url) } }
    }
}

struct FilePreview: UIViewControllerRepresentable {
    let url: URL
    func makeCoordinator() -> Coordinator { Coordinator(url) }
    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController()
        controller.dataSource = context.coordinator
        return controller
    }
    func updateUIViewController(_ controller: QLPreviewController, context: Context) {}
    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        let url: URL
        init(_ url: URL) { self.url = url }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem { url as NSURL }
    }
}
