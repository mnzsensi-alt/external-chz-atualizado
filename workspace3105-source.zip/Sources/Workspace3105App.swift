import SwiftUI

@main
struct Workspace3105App: App {
    @StateObject private var store = WorkspaceStore()
    var body: some Scene {
        WindowGroup {
            WorkspaceHome().environmentObject(store)
                .tint(.orange)
                .preferredColorScheme(.dark)
                .onOpenURL { store.importPackage($0) }
        }
    }
}
